package entities;

public abstract class Entitati {

}
