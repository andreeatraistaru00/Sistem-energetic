package data;

public abstract class Entitati {

}
